package com.assignment;

import com.assignment.data.Assignment;
import com.assignment.data.Student;
import com.assignment.data.Teacher;

import java.util.ArrayList;
import java.util.List;
import static com.assignment.util.Display.*;

public class Main {

    private static List<Student> studentList = new ArrayList<>();
    private static List<Teacher> teacherList = new ArrayList<>();
    private static List<Assignment> assignmentList = new ArrayList<>();

    public static void main(String[] args) {

        readStudentDetails();
        readTeacherDetails();
        readAssignmentDetails();

        showAllDetails();

    }

    private static void readStudentDetails(){
        while (shouldAddStudent()) {
            Student student = new Student();

            display("Enter student Name:");
            String username = readLine();

            display("Register " + username + " for a course");
            String course = readLine();

            student.setName(username);
            student.setCourse(course);

            studentList.add(student);
            display("Student name recorded \n");
        }

    }

    private static void readTeacherDetails(){
        while (shouldAddTeacher()) {
            display("Enter teacher Name:");
            String name = readLine();
            Teacher teacher = new Teacher();
            teacher.setName(name);
            teacherList.add(teacher);
            display("Teacher name recorded \n");
        }

    }

    private static void readAssignmentDetails() {
        while (shouldAddAssignment()) {
            display("Enter assignment Name:");
            String name = readLine();
            Assignment assignment = new Assignment();
            assignment.setName(name);
            assignmentList.add(assignment);
            display("Assignment name recorded \n");
        }
    }

    private static boolean shouldAddAssignment() {
        display("Add an Assignment? (Y/N)");
        String answer = readLine();
        if(answer.equalsIgnoreCase("Y")) {
            return true;
        } else {
            return false;
        }
    }

    private static boolean shouldAddTeacher() {
        display("Add a teacher? (Y/N)");
        String answer = readLine();
        if(answer.equalsIgnoreCase("Y")) {
            return true;
        } else {
            return false;
        }
    }

    private static boolean shouldAddStudent(){
        display("Add a student? (Y/N)");
        String answer = readLine();
        if(answer.equalsIgnoreCase("Y")) {
            return true;
        } else {
            return false;
        }
    }

    private static void showAllDetails() {
        display("Showing all details");

        display("Students registered in the school:");
        for (Student student: studentList){
            display(student.getName() + "-" + student.getCourse());
            display("");
        }

        display("Teachers registered in the school:");
        for (Teacher teacher: teacherList){
            System.out.println(teacher.getName());
            display("");
        }

        display("Assignments available:");
        for (Assignment assignment: assignmentList){
            System.out.println(assignment.getName());
        }
    }
}
