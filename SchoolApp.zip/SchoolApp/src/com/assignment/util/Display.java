package com.assignment.util;

import java.util.Scanner;

public class Display {
    public static void display(String string){
        System.out.println(string);
    }

    public static String readLine(){
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }
}
